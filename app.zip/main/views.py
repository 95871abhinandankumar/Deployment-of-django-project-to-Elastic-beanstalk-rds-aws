from django.http.response import HttpResponse
from django.shortcuts import render
from django.contrib import messages
from django.contrib.auth.forms import UserCreationForm
from django.http import HttpRequest
from .models import feedback

def home(request):
    if request.method == "POST":
        feedback_form = feedback()
        feedback_form.fname = request.POST.get('fname')
        feedback_form.lname = request.POST.get('lname')
        feedback_form.country = request.POST.get('country')
        feedback_form.describeFeedback = request.POST.get('describeFeedback')
        feedback_form.save()
        return HttpResponse("<h1>Feedback successfully submitted</h1>")
    return render(request,'home.html')

# User Register
def register(request):
    form=UserCreationForm
    if request.method=='POST':
        regForm=UserCreationForm(request.POST)
        if regForm.is_valid():
            regForm.save()
            messages.success(request,'User has been registered.')
    return render(request,'registration/register.html',{'form':form})


