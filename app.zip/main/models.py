from django.db import models
# Create your models here.

class feedback(models.Model):
    fname = models.CharField(max_length=100, default='unknown')
    lname = models.CharField(max_length=100, default='unknown')
    country = models.CharField(max_length=100, default='')
    describeFeedback = models.TextField(default='good')
    
